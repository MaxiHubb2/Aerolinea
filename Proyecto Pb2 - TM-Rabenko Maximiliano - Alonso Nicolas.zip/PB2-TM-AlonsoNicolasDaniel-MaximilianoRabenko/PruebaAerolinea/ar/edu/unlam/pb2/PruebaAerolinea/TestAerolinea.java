package ar.edu.unlam.pb2.PruebaAerolinea;

import static org.junit.Assert.assertEquals;


import java.time.LocalDate;
import java.time.LocalTime;

import org.junit.Test;



public class TestAerolinea {

	
	
	@Test
	public void queSePuedaSubirUnPasajeroAlVuelo() {
		
		String nombre = "Maxi";
		String apellido = "Rabenko";
		Integer dni = 37609434;
		Double pasaporte = 20.376094341;
		Integer idDePasajero = 1;
		String tipoDePasajero = "VIP";
		
		
		Vuelos primerVuelo = new Vuelos();
		
		Persona pasajero1 = new Pasajeros(nombre,apellido,pasaporte,dni, idDePasajero,tipoDePasajero);
		
		primerVuelo.agregarPasajeroAlVuelo(pasajero1);
		
		Integer valorEsperado = 1;
		Integer valorObtenido = primerVuelo.getCantidadDePasajeros();
		
		assertEquals(valorEsperado,valorObtenido);
	}
	
//	@Test
//	public void queSePuedaAsignarUnAsientoDelVueloAUnPasajero() {
//		
//		String nombre = "Maxi";
//		String apellido = "Rabenko";
//		Integer dni = 37609434;
//		Double pasaporte = 20.376094341;
//		
//		Vuelos primerVuelo = new Vuelos();
//		
//		Persona pasajero1 = new Pasajeros(nombre,apellido,pasaporte,dni);
//		
//		primerVuelo.asignarUnAsientoAUnPasajero(pasajero1);
//		
//		Integer valorEsperado = 1;
//		Integer valorObtenido = primerVuelo.cantidadDeAsientos();
//		
//		assertEquals(valorEsperado,valorObtenido);
//	}
	

	@Test
	public void queSePuedaComprarUnPasajeParaUnPasajero(){
		String destinoDelPsajero = "Tierra del Fuego";
		String nombre = "Carlos";
		Integer IDPasaje = 1;
		String tipoDePasajero = "VIP";
		Integer IDPasajero1 = 1;
		
		Pasajes pasaje = new Pasajes();
		Vuelos nuevoVuelo = new Vuelos();
		Pasajeros pasajero1 = new Pasajeros(tipoDePasajero, destinoDelPsajero ,IDPasaje, nombre, IDPasajero1);
		
		
		Boolean pasajeEsperado = true;
		Boolean pasajeObtenido = nuevoVuelo.comprarPasaje(pasajero1,pasaje);
		 
		assertEquals(pasajeEsperado,pasajeObtenido);
	}
	
	@Test
	public void queNoSePuedaComprar2PasajesParaElMismoPasajeroYVuelo(){
		String destinoDelPsajero = "Tierra del Fuego";
		String nombre = "Carlos";
		Integer IDPasajero1 = 1;
		
		String nombre2 = "Carlos";
		Integer IDPasajero2 = 2;
		
		Integer IDPasaje = 1;
		String tipoDePasajero = "VIP";
		
		Integer numeroDeVuelo=1;
		Double PrecioDelPasaje = 200.0;
		
		
		Pasajeros pasajero1 = new Pasajeros(tipoDePasajero, destinoDelPsajero ,IDPasaje, nombre, IDPasajero1);
		
		Pasajeros pasajero2 = new Pasajeros(tipoDePasajero, destinoDelPsajero ,IDPasaje, nombre, IDPasajero1);
	
		Pasajes nuevoPasaje = new Pasajes();
		Vuelos nuevoVuelo = new Vuelos();
		
		nuevoVuelo.agregarPasajeroAlVuelo(pasajero1);
		nuevoVuelo.agregarPasajeroAlVuelo(pasajero2);
		
		Boolean pasajeEsperado = true;
		Boolean pasajeObtenido = nuevoVuelo.queNoSePuedaComprarPasajes(pasajero1,pasajero2,nuevoPasaje);
		 
		assertEquals(pasajeEsperado,pasajeObtenido);
		
	}
	
	@Test
	public void queALosPasajerosVipSeLeApliqueUn5PorcientoDeDescuento(){
		String nombre = "Maxi";
		String apellido = "Rabenko";
		Integer dni = 37609434;
		Double pasaporte = 20.376094341;
		Integer idDePasajero = 1;
		String tipoDePasajero = "VIP";
		
		Vuelos primerVuelo = new Vuelos();
		
		Pasajeros pasajero1 = new Pasajeros(nombre,apellido,pasaporte,dni, idDePasajero,tipoDePasajero);
		Pasajes pasaje = new Pasajes(tipoDePasajero, tipoDePasajero, idDePasajero, tipoDePasajero, idDePasajero, pasaporte);
		
		primerVuelo.asignarUnAsientoAUnPasajero(pasajero1);
		
		Boolean valorEsperado = true;
		Boolean valorObtenido = primerVuelo.comprarPasajeVip(pasajero1, pasaje);
		
		
		assertEquals(valorEsperado,valorObtenido);
		
	}
	
	@Test
	public void queSePuedaAsignarUnAsientoParaUnPasajeroEnUnVuelo(){
		String nombre = "Maxi";
		String apellido = "Rabenko";
		Integer dni = 37609434;
		Double pasaporte = 20.376094341;
		Integer idDePasajero = 1;
		String tipoDePasajero = "VIP";
		
		
		Vuelos primerVuelo = new Vuelos();
		
		Persona pasajero1 = new Pasajeros(nombre,apellido,pasaporte,dni, idDePasajero,tipoDePasajero);
		
		primerVuelo.asignarUnAsientoAUnPasajero(pasajero1);
		
		Integer valorEsperado = 1;
		Integer valorObtenido = primerVuelo.cantidadDeAsientos();
		
		assertEquals(valorEsperado,valorObtenido);
	}
	
	@Test
	public void queNoSePuedaAsignarUnAsientoAUnVueloSiElAsientoEstaOcupado(){
		
	}
	
	@Test
	public void queNoSePuedaAsignarUnAsientoSiElAvionYaDespego(){
		
	}
	
	@Test
	public void queSePuedaObtenerUnaListaDePasajerosQueNoVolaron(){
		
	}
}
