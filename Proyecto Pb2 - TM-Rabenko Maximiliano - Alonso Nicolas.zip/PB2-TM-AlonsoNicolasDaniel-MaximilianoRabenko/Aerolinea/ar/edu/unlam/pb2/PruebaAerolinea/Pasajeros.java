package ar.edu.unlam.pb2.PruebaAerolinea;

public class Pasajeros extends Persona{

	
	private String nombre, apellido;
	private Integer dni;
	private Double pasaporte;
	private Integer IDpasajero;
	private String tipoDePasajero;

	public Pasajeros(String nombre, String apellido, Double pasaporte, Integer dni, Integer IDpasajero, String tipoDePasajero) {
		super(nombre, apellido, pasaporte,dni);
		this.tipoDePasajero = tipoDePasajero;
	}
	
	public Pasajeros(String tipoDePasajero2, String destinoDelPsajero, Integer iDPasaje, String nombre2, Integer iDPasajero1) {
		// TODO Auto-generated constructor stub
		this.tipoDePasajero = tipoDePasajero;

	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public Double getPasaporte() {
		return pasaporte;
	}

	public void setPasaporte(Double pasaporte) {
		this.pasaporte = pasaporte;
	}

	public Integer getDni() {
		return dni;
	}

	public void setDni(Integer dni) {
		this.dni = dni;
	}

	public Integer getIDpasajero() {
		return IDpasajero;
	}

	public void setIDpasajero(Integer iDpasajero) {
		IDpasajero = iDpasajero;
	}

	@Override
	public String toString() {
		return "Pasajeros [nombre=" + nombre + ", apellido=" + apellido + ", dni=" + dni + ", pasaporte=" + pasaporte
				+ ", IDpasajero=" + IDpasajero + "]";
	}
	
}
