package ar.edu.unlam.pb2.PruebaAerolinea;

public enum TipoAvion {

	BOING_747,
	TREN_DE_LAS_NUBES,
	EL_AVION,
	FERRARI;
	
}
