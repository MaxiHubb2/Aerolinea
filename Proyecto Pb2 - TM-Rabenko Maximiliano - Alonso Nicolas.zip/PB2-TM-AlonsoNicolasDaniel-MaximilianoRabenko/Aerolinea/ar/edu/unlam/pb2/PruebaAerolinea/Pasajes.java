package ar.edu.unlam.pb2.PruebaAerolinea;

public class Pasajes{

	private String destino,nombre,tipoDePasajero;
	private Integer IDPasaje;
	private Pasajeros pasajero;
	private Double precioDelPasaje;

	


	public Pasajes(String tipoDePasajero, String destinoDelPsajero, Integer iDPasaje, String nombre, Integer IDpasajero, Double precioPasaje) {
		this.destino = destinoDelPsajero;
		this.nombre = nombre;
		this.IDPasaje = iDPasaje;
		this.precioDelPasaje = precioPasaje;
		this.tipoDePasajero = tipoDePasajero;
				
	}
 

	public Pasajes() {
		// TODO Auto-generated constructor stub
		this.tipoDePasajero = tipoDePasajero;

	}


	public String getDestino() {
		return destino;
	}


	public void setDestino(String destino) {
		this.destino = destino;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getTipoDePasajero() {
		return tipoDePasajero;
	}


	public void setTipoDePasajero(String tipoDePasajero) {
		this.tipoDePasajero = tipoDePasajero;
	}


	public Integer getIDPasaje() {
		return IDPasaje;
	}


	public void setIDPasaje(Integer iDPasaje) {
		IDPasaje = iDPasaje;
	}

	public Pasajeros getPasajero() {
		return pasajero;
	}


	public void setPasajero(Pasajeros pasajero) {
		this.pasajero = pasajero;
	}


	public Double getPrecioDelPasaje() {
		return precioDelPasaje;
	}


	public void setPrecioDelPasaje(Double precioDelPasaje) {
		this.precioDelPasaje = precioDelPasaje;
	}

	@Override
	public String toString() {
		return "Pasajes [destino=" + destino + ", nombre=" + nombre + ", tipoDePasajero=" + tipoDePasajero
				+ ", IDPasaje=" + IDPasaje + "]";
	}
	
	
}
